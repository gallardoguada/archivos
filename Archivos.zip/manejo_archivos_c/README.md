# 📂 Manejo de Archivos en C

Este repositorio contiene ejemplos prácticos del uso de archivos en lenguaje C, incluyendo lectura y escritura en archivos binarios y de texto, manipulación del indicador de posición y uso de punteros.

## 📁 Contenido

- `src/`: Código fuente en C
- `ejemplos/`: Archivos de ejemplo (`.dat`)
- `README.md`: Documentación general

## ✅ Temas Cubiertos

- Archivos binarios y de texto
- Funciones: `fopen()`, `fclose()`, `fread()`, `fwrite()`, `fprintf()`, `fscanf()`, `fseek()`, `ftell()`, `feof()`
- Uso de punteros `FILE *`
- Manejo de estructuras en archivos

## 🚀 Ejecución

Compilar con:
```bash
gcc src/escribir_binario.c -o escribir_binario
```

Ejecutar con:
```bash
./escribir_binario
```
