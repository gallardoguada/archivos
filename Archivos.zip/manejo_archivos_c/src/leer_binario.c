#include <stdio.h>
#include <stdlib.h>

#define ARCHIVO "ejemplos/bin.dat"

struct Persona {
    char nombre[10];
    int edad;
};

int main() {
    FILE *archivo;
    struct Persona persona;
    int cantidad;

    archivo = fopen(ARCHIVO, "rb");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo.\n");
        return 1;
    }

    while (!feof(archivo)) {
        cantidad = fread(&persona, sizeof(persona), 1, archivo);
        if (cantidad == 1)
            printf("Nombre: %s - Edad: %d\n", persona.nombre, persona.edad);
    }

    fclose(archivo);
    return 0;
}
