#include <stdio.h>

#define ARCHIVO "ejemplos/bin.dat"

int main() {
    FILE *archivo;
    long tamaño;

    archivo = fopen(ARCHIVO, "rb");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo.\n");
        return 1;
    }

    fseek(archivo, 0L, SEEK_END);
    tamaño = ftell(archivo);
    fclose(archivo);

    printf("El archivo tiene %ld bytes\n", tamaño);
    return 0;
}
