#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ARCHIVO "ejemplos/bin.dat"

struct Persona {
    char nombre[10];
    int edad;
};

int main() {
    FILE *archivo;
    struct Persona persona;

    archivo = fopen(ARCHIVO, "wb");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo.\n");
        return 1;
    }

    strcpy(persona.nombre, "Pedro");
    persona.edad = 28;

    fwrite(&persona, sizeof(persona), 1, archivo);
    fclose(archivo);
    printf("Archivo binario escrito correctamente.\n");

    return 0;
}
